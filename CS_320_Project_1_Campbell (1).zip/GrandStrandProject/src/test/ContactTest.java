package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import contact.Contact;
import contact.ContactService;

public class ContactTest {

    // Tests the Contact Object requirements
    @Test
    void testContactClassValidation() {
        Contact contact = new Contact("ID123", "Alex", "Campbell", "1234567890", "123 Main St");
        assertEquals("ID123", contact.getContactId());
        
        // Test ID too long (Fail)
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "FirstName", "LastName", "1234567890", "Address");
        });
        
        // Test Phone wrong length (Fail)
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("ID", "FirstName", "LastName", "123", "Address");
        });
    }

    // Tests the Contact Service requirements
    @Test
    void testContactServiceFunctionality() {
        ContactService service = new ContactService();
        Contact c = new Contact("1", "Alex", "C", "1234567890", "Address");
        
        service.addContact(c);
        assertNotNull(service.getContact("1"));
        
        service.updateContact("1", "Bob", "Smith", "0987654321", "New Road");
        assertEquals("Bob", service.getContact("1").getFirstName());
        
        service.deleteContact("1");
        assertNull(service.getContact("1"));
    }
}