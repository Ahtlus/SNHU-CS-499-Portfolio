package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import task.Task;
import task.TaskService;

public class TaskTest {

    // Tests Task Object requirements
    @Test
    void testTaskClassValidation() {
        Task task = new Task("T1", "Finish Milestone", "Submit the final project files");
        assertEquals("T1", task.getTaskId());
        
        // Test Name too long (>20 chars)
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T1", "This name is definitely way too long for the requirement", "Desc");
        });
    }

    // Tests Task Service requirements
    @Test
    void testTaskServiceFunctionality() {
        TaskService service = new TaskService();
        Task t = new Task("1", "Name", "Description");
        
        service.addTask(t);
        assertNotNull(service.getTask("1"));
        
        service.updateTask("1", "New Name", "New Description");
        assertEquals("New Name", service.getTask("1").getName());
        
        service.deleteTask("1");
        assertNull(service.getTask("1"));
    }
}