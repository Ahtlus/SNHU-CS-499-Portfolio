package appointment;
import java.util.Date;

public class Appointment {
    private final String appointmentId;
    private final Date appointmentDate;
    private final String description;

    public Appointment(String id, Date date, String desc) {
        if (id == null || id.length() > 10) throw new IllegalArgumentException("Invalid ID");
        if (date == null || date.before(new Date())) throw new IllegalArgumentException("Invalid Date");
        if (desc == null || desc.length() > 50) throw new IllegalArgumentException("Invalid Desc");

        this.appointmentId = id;
        this.appointmentDate = date;
        this.description = desc;
    }

    public String getAppointmentId() { return appointmentId; }
    public Date getAppointmentDate() { return appointmentDate; }
    public String getDescription() { return description; }
}