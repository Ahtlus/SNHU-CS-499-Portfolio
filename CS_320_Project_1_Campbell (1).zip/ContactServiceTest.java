import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    @Test
    void testAddContact() {
        Contact contact = new Contact("12345", "Alex", "Campbell", "1234567890", "123 Bama Way");
        assertTrue(service.addContact(contact));
    }

    @Test
    void testAddDuplicateId() {
        Contact contact1 = new Contact("12345", "Alex", "Campbell", "1234567890", "123 Bama Way");
        Contact contact2 = new Contact("12345", "Jordan", "Smith", "0987654321", "456 Auburn St");
        service.addContact(contact1);
        assertFalse(service.addContact(contact2)); // Should fail due to duplicate ID
    }

    @Test
    void testDeleteContact() {
        Contact contact = new Contact("12345", "Alex", "Campbell", "1234567890", "123 Bama Way");
        service.addContact(contact);
        assertTrue(service.deleteContact("12345"));
        assertFalse(service.deleteContact("12345")); // Should fail, already deleted
    }

    @Test
    void testUpdateContactFields() {
        Contact contact = new Contact("12345", "Alex", "Campbell", "1234567890", "123 Bama Way");
        service.addContact(contact);
        
        assertTrue(service.updateFirstName("12345", "Alexander"));
        assertTrue(service.updateLastName("12345", "C"));
        assertTrue(service.updateNumber("12345", "1112223333"));
        assertTrue(service.updateAddress("12345", "456 New Lane"));
    }

    @Test
    void testUpdateInvalidId() {
        assertFalse(service.updateFirstName("99999", "Ghost")); // ID doesn't exist
    }
}