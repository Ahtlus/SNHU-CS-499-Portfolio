package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import appointment.Appointment;
import appointment.AppointmentService;

public class AppointmentServiceTest {
    @Test
    void testAddAppointment() {
        AppointmentService as = new AppointmentService();
        // Set date to tomorrow to avoid "past date" error
        Date tomorrow = new Date(System.currentTimeMillis() + 86400000);
        Appointment a = new Appointment("1", tomorrow, "Doctor visit");
        as.addAppointment(a);
        assertNotNull(as.getAppointment("1"));
    }

    @Test
    void testInvalidDate() {
        Date yesterday = new Date(System.currentTimeMillis() - 86400000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1", yesterday, "Desc");
        });
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService as = new AppointmentService();
        Date tomorrow = new Date(System.currentTimeMillis() + 86400000);
        as.addAppointment(new Appointment("1", tomorrow, "Desc"));
        as.deleteAppointment("1");
        assertNull(as.getAppointment("1"));
    }
    @Test
    void testAddDuplicateAppointment() {
        AppointmentService as = new AppointmentService();
        Date tomorrow = new Date(System.currentTimeMillis() + 86400000);
        Appointment a = new Appointment("1", tomorrow, "Desc");
        as.addAppointment(a);
        
        // Assert that adding the same ID throws an exception
        assertThrows(IllegalArgumentException.class, () -> as.addAppointment(a));
    }

    @Test
    void testDeleteNonExistentAppointment() {
        AppointmentService as = new AppointmentService();
        // Assert that deleting a non-existent ID throws an exception
        assertThrows(IllegalArgumentException.class, () -> as.deleteAppointment("999"));
    }
}